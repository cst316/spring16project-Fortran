==========About Memoranda==========
Memoranda is a scheduling tool that will help developers and 
anybody, involved in the software process, stay on track and on the same page. 
This one of a kind tool will increase the efficiency and pace that your team produce in day to day activities.

==========How To Install==========
When finish downloading Memoranda, extract memoranda.zip in an empty folder wherever you wish.
After extraction, run the memoranda by double clicking memoranda.jar.


==========What Is New To Memoranda==========
There are four new additions to Memoranda.

1) A Timer
2) A Stopwatch
3) Import Code
4) Imported Code


==========Timer==========
The Timer is to tell you when the task is to be completed. 

When you create a task, check the timer checkbox and it will be created when you click the "ok" button.
A new window will appear. You can set the estimated time you think it would take to complete your task.
When the timer reaches zero, the timer will then display, in red, that the time is over.

You can also, pause, reset, and continue at anytime.


==========Stopwatch==========
The stopwatch feature is to help you measure how long it takes to complete a task.

When you create a new task, check the stopwatch checkbox and the stopwatch window will be created when
you click the "ok" button. Once the window appears, you can start the timer at any time. 

You can pause and also reset the time. Resetting the time without pausing, will cause the stopwatch to reset to zero; 
however, the time will continue to count.


==========Import Code==========
Import code helps you keep track of how many lines you have written in a java program. 
If needed, you can import multiple java files, but they must be in a zip file.
When you enter a java file or a zip file, with java files, it will count the number of lines in the java file;
this ignores empty and commented lines.

In order to import your code, go to the menubar, click on File then click on Import Code.
A file chooser window will appear and you can navigate to the java file you want to import.

The same steps are taken when importing a zip file; 
however, change the file filter to zip and find the zip file you want to import.

After importing, a new window will emerge. The window will show all your imported code, 
along with the number of lines it has counted for that java file.

*****Note*****
You can not import a file with the same name. Even if there is a duplicate in the zip file. If a
zip file contains files with the same name in multiple directories the file in the top most directory will be added
to the table and the remaining will be ignored.

==========Imported Code==========
There is a way to view the imported codes without importing a file.

In order to view the code you have imported without importing a file; 
go to View then click on Imported Code and the table will appear.

You can search for files in the table. When searching, in the seach bar, without checking the "Contains Name", 
you must enter the full name of the file, including ".java".
When checking the "Contains Name" checkbox, you can put a small amount of the name and hit the Enter key it will display the closest result.

*****Note*****
The search is NOT case sensitive.


==========Uninstall==========
To uninstall, delete the folder wherever you placed Memoranda.jar.

*****Windows 10*****
Open your file explorer, then go to the menubar and click on File, then "Change folder and search option".
A window will emerge, then go to the "view" tab and check the radio button called "Show hidden folders", then click ok.

Open your file explorer, then go to your c drive. Find and click on the user folder, then click on the folder that has your username.
Find a folder called ".memoranda" and delete that folder. 

*****Windows 8*****
Open your file explorer, then go to your c drive and then click on users. 
Right click on the folder with your username and click on properties, and checkMark the hidden Checkbox.
Go into your username folder and find ".memoranda and delete it.
For Example
"C:\Users\yourName\.memeroanda"


*****Important Note*****
For Windows XP Users, If your file system contains a huge amount of .zips the JFileChooser
tends to hang in Memoranda some Windows 8 users may experience this as well. In order to 
mitigate this open command prompt and enter the following command. This will
unRegister .zip in dll.

regsvr32 /u %windir%\system32\zipfldr.dll

To undo this change and register dll

regsvr32 zipfldr.dll

More information about this can be found here
http://www.bosit.be/blog/2008/09/26/fixing-the-slow-jfilechooser-on-windows-xp/


==========CopyRight==========
This was created by Team Fortran
Members of Team Fortran:
Talab Hussein
Saul Lopez
Quy Ly
Miguel Zavala
Mike Zaragoza
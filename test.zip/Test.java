package Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//This is just to test if things work, since we don't have a main yet. Easier to test little by little.

public class Test {
    
    public static void main(String[] args) {
        int Solution [][] = generateSolution(new int [9][9], 0);
        int Matrix1 [][] = Solution;
        print (Matrix1);
        
        int Game [][] = generateGame(Solution);

        print (Game);
    }
    

        //Validates if a number is placeable in its row
    public static boolean ValidX(int Matrix [][], int Column, int Number) {
        for (int Row = 0; Row < 9; Row++) {
            if (Matrix[Column][Row] == Number){
                return false;
            }
        }
        return true;
    }
    
    //Validates if a number is placeable in its column
    public static boolean ValidY(int Matrix [][], int Row, int Number) {
        for (int Column = 0; Column < 9; Column++) {
            if (Matrix [Column][Row] == Number) {
                return false;
            }
        }
        return true;
    }
    
    //Validates if a number is placeable in 3x3 box
    public static boolean ValidBox (int Matrix [][], int Row, int Column, int Number) {
        int subRow;
        int subColumn;
        
        if (Row < 3) {
            subRow = 0;
        } else if (Column < 6) {
            subRow = 3;
        } else {
            subRow = 6;
        }
        
        if (Column < 3) {
            subColumn = 0;
        } else if (Column < 6) {
            subColumn = 3;
        } else {
            subColumn = 6;
        }
        
        for (int ColumnY = subColumn; ColumnY < subColumn + 3; ColumnY++) {
            for (int RowX = subRow; RowX < subRow + 3; RowX++) {
                if (Matrix[ColumnY][RowX] == Number) {
                    return false;
                }
            }
        }
        return true;
    }
    
    //Gets the next possible number for given position or -1 when empty
    public static int getNextNumber (int Matrix [][], int Row, int Column, List<Integer> Num) {
        while (Num.size() > 0) {
            int Number = Num.remove(0);
            if (ValidX (Matrix, Column, Number) 
                    && ValidY (Matrix, Row, Number) 
                    && ValidBox (Matrix, Row, Column, Number)) {
                return Number;
            }
        }
        return -1;
    } 
    
    //Generates the solution for the Sudoku game
    //Solution is always different after each run.
    public static int [][] generateSolution (int Matrix [][], int index) {
        if (index >= 81) {
            return Matrix;
        }
        
        int Row = index % 9;
        int Column = index / 9;
        
        //Random number generater.
        //takes numbers 1-9 and shuffles them and places them in blanks.
        List<Integer> Num = new ArrayList<>();
        for (int i = 1; i <= 9; i++) {
            Num.add(i);
        }
        Collections.shuffle(Num);
        
        while (Num.size() > 0) {
            int Number = getNextNumber(Matrix, Row, Column, Num);
            if (Number == -1) {
                return null;
            }
            
            Matrix [Column][Row] = Number;
            int TempMatrix [][] = generateSolution(Matrix, index + 1);
            if (TempMatrix != null) {
                return TempMatrix;
            }
            Matrix [Column][Row] = 0;
        }
        return null;
    }
    
    //prints Sudoku
    public static void print (int Matrix [][]) {
        System.out.println();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(Matrix[j][i]);
            }
        System.out.println();
        }
    }
    
    //Generates the game using the Solution
    public static int [][] generateGame(int Matrix [][]) {
        List<Integer> Position = new ArrayList<>();
        for (int i = 1; i <= 9; i++) {
            Position.add(i);
        }
        Collections.shuffle(Position);
        return generateGame(Matrix, Position);
    }
    
    //Removes number from random spots
    public static int [][] generateGame (int Matrix [][], List<Integer> Positions) {
        while (Positions.size() > 0) {
            int Pos = Positions.remove(0);
            int Row = Pos % 9;
            int Column = Pos / 9;
            int TempMatrix = Matrix[Column][Row];
            Matrix[Column][Row] = 0;
            
            if (!Validity(Matrix))
                Matrix [Column][Row] = TempMatrix;
        }
        return Matrix;
    }
    
    //Checks if the game is valid
    public static boolean Validity (int Matrix [][]) {
        return Validity(Matrix, 0, new int[] {0});
    }
    
    //Checks if the game only has one solution.
    public static boolean Validity(int Matrix [][], int index, int Solutions []) {
        if (index >= 81) {
            return ++Solutions [0] == 1;
        }
        
        int Row = index % 9;
        int Column = index / 9;
        
        if (Matrix [Column][Row] == 0) {
            List<Integer> Numbers = new ArrayList<>();
            for (int i = 1; i <= 9; i++) {
                Numbers.add(i);
            }
            
            while (Numbers.size() > 0) {
                int Num = getNextNumber(Matrix, Row, Column, Numbers);
                if (Num == -1) {
                    break;
                }
                Matrix [Column][Row] = Num;
                
                if (!Validity (Matrix, index + 1, Solutions)) {
                    Matrix [Column][Row] = 0;
                    return false;
                }
                Matrix [Column][Row] = 0;
            }
            
        }
        else if (!Validity (Matrix, index + 1, Solutions)) {
                return false;
        }
        return true;
    }
         
}

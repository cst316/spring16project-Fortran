package sudoku;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sudoku //extends SudokuGUI
{
      //Validates if a number is placeable in its row
    public static boolean ValidX(int Matrix [][], int y, int Number) {
        for (int x = 0; x < 9; x++) {
            if (Matrix[y][x] == Number){
                return false;
            }
        }
        return true;
    }
    
    //Validates if a number is placeable in its column
    public static boolean ValidY(int Matrix [][], int x, int Number) {
        for (int y = 0; y < 9; y++) {
            if (Matrix [y][x] == Number) {
                return false;
            }
        }
        return true;
    }
    
    //Validates if a number is placeable in 3x3 box
    public static boolean ValidBox (int Matrix [][], int x, int y, int Number) {
        int subX;
        int subY;
        
        if (x < 3) {
            subX = 0;
        } else if (x < 6) {
            subX = 3;
        } else {
            subX = 6;
        }
        
        if (y < 3) {
            subY = 0;
        } else if (y < 6) {
            subY = 3;
        } else {
            subY = 6;
        }
        
        for (int yy = subY; yy < subY + 3; yy++) {
            for (int xx = subX; xx < subX + 3; xx++) {
                if (Matrix[yy][xx] == Number) {
                    return false;
                }
            }
        }
        return true;
    }
    
    //Gets the next possible number for given position or -1 when empty
    public static int getNextNumber (int Matrix [][], int x, int y, List<Integer> Num) {
        while (Num.size() > 0) {
            int Number = Num.remove(0);
            if (ValidX (Matrix, y, Number) 
                    && ValidY (Matrix, x, Number) 
                    && ValidBox (Matrix, x, y, Number)) {
                return Number;
            }
        }
        return -1;
    } 
    
    //Like it says, generates the solution for the Sudoku game
    public static int [][] generateSolution (int Matrix [][], int index) {
        if (index >= 81) {
            return Matrix;
        }
        
        int x = index % 9;
        int y = index / 9;
        
        //Pretty much the random number generater.
        //takes numbers 1-9 and shuffles them and places them in blanks.
        List<Integer> Num = new ArrayList<>();
        for (int i = 1; i <= 9; i++) {
            Num.add(i);
        }
        Collections.shuffle(Num);
        
        while (Num.size() > 0) {
            int Number = getNextNumber(Matrix, x, y, Num);
            if (Number == -1) {
                return null;
            }
            
            Matrix [y][x] = Number;
            int tempMatrix [][] = generateSolution(Matrix, index + 1);
            if (tempMatrix != null) {
                return tempMatrix;
            }
            Matrix [y][x] = 0;
        }
        return null;
    }
    
    //prints Sudoku
    public static void print (int Matrix [][]) {
        System.out.println();
        for (int i = 0; i < 9; i++) {
         for (int j = 0; j < 9; j++){   
                System.out.print(Integer.toString(Matrix[j][i]));
         
            }
        System.out.println();
        }
    }
    
    //trying to generate the game but it is taking all the numbers, besides the first one and setting them to 0/blanks.
    public static int [][] generateGame(int Matrix [][]) {
        List<Integer> Position = new ArrayList<>();
        for (int i = 1; i < 81; i++) {
            Position.add(i);
        }
        Collections.shuffle(Position);
        return generateGame(Matrix, Position);
    }
    
    public static int [][] generateGame (int Matrix [][], List<Integer> Position) {
        while (Position.size() > 0) {
            int Pos = Position.remove(0);
            int x = Pos % 9;
            int y = Pos / 9;
            int TempMatrix = Matrix[y][x];
            Matrix[y][x] = 0;
            
            if (!Validity(Matrix)) {
                Matrix [y][x] = TempMatrix;
            }
        }
        return Matrix;
    }
    
    public static boolean Validity (int Matrix [][]) {
        return Validity(Matrix, 0, new int[] {0});
    }
    
    public static boolean Validity(int Matrix [][], int index, int Solutions []) {
        if (index >= 81) {
            return ++Solutions [0] == 1;
        }
        
        int x = index % 9;
        int y = index / 9;
        
        if (Matrix [y][x] == 0) {
            List<Integer> Numbers = new ArrayList<>();
            for (int i = 1; i <= 9; i++) {
                Numbers.add(i);
            }
            
            while (Numbers.size() > 0) {
                int Num = getNextNumber(Matrix, x, y, Numbers);
                if (Num == -1) {
                    break;
                }
                Matrix [y][x] = Num;
                
                if (!Validity (Matrix, index + 1, Solutions)) {
                    Matrix [y][x] = 0;
                    return false;
                }
                Matrix [y][x] = 0;
            }
            
        }
        else if (!Validity (Matrix, index + 1, Solutions)) {
                return false;
        }
        return true;
    }
}
package sudoku;

import java.awt.GridLayout; //for grids
import java.awt.Color; //color background foreground
import java.awt.Font; //font
import javax.swing.*;




public class SudokuGUI extends Sudoku //borrowing generated puzzle and solution from Sudoku class.
{
    private JFrame frame = new JFrame("Sudoku Game");
    private JPanel Panel= new JPanel(new GridLayout(3,3));//Panel with grid layout.
    private JPanel MainPanel[][] = new JPanel[3][3];
    private JTextField board[][] = new JTextField[3][3]; //User input 
    private int Solution [][] = generateSolution(new int [9][9], 0);
    private  int Game [][] = generateGame(Solution);
    private String strarr[][] = new String[9][9];
    private int countx=0, county =0, iteration = 0; //variables used to set 9x9 array into 3x3.
    public SudokuGUI() {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //for close button to work
            frame.setVisible(true); //to show things inside the frame
            frame.setSize(500,500); //size may vary
            
            //String array copies Game array but replaces 0's with empty strings. 
           for (int i = 0; i < 9; i++){
                for (int j =0; j < 9; j++){ 
                    if(Game[i][j] ==0){
                    strarr[i][j] = " ";    
                        
                   }
                    else{
                    strarr[i][j] =Integer.toString(Game[i][j]);
                    }
            }
        }
        //for the outer panel.
            for (int g = 0; g < 3; g++){
              for(int h = 0; h<3; h++){
                  MainPanel[g][h] = new JPanel(new GridLayout(3,3));// creates a grid layout within the index of the panel for the TextField
                  MainPanel[g][h].setBorder(BorderFactory.createLineBorder(Color.black, 3));
                  //For grid inside the panels
                for(int i =0; i < 3; i++){
                    for (int j =0; j < 3; j++){
                    //SetBorders and Create objects
                       
                        board[i][j] = new JTextField(strarr[countx][county]);//
                        board[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                        
                     //Set font
                        Font font = new Font("Times New Roman", Font.PLAIN, 20);
                        board[i][j].setFont(font);
                    
                    //background
                        board[i][j].setOpaque(true);
                        board[i][j].setForeground(Color.black);
                        board[i][j].setBackground(Color.white);
                   
                     // adding Textfield array on Panel element
                        MainPanel[g][h].add(board[i][j]);
                        
                        
                        county+=1;
                       //created so that y does not exceed certain upperlimits based on iteration.
                     if (iteration == 0 || iteration == 3 || iteration == 6){
                        if (county > 2){
                         county = 0;
                        }
                      }
                     else if (iteration == 1 || iteration == 4 || iteration == 7){
                      if (county > 5){
                        county = 3;
                        }  
                      }
                     else if (iteration == 2 || iteration == 5 || iteration == 8){
                        if (county > 8){
                        county = 6;
                        }
                      }
              }
                        countx+=1; //countx is automatically set by iteration
            } 
                        Panel.add(MainPanel[g][h]);//adding Panel element to main Panel.
                   iteration+=1;
                  //The following if statements set the initial value of x and y for every upcomming loop.
                   if (iteration == 1){
                    countx = 0;
                    county = 3;
                    }
                   else if(iteration == 2){
                    countx = 0;
                    county = 6;
                    }
                   else if(iteration == 3){
                    countx = 3;
                    county = 0;
                    }
                   else if(iteration == 4){
                    countx = 3;
                    county = 3;
                    }
                   else if(iteration == 5){
                    countx = 3;
                    county = 6;
                    }
                   else if(iteration == 6){
                    countx = 6;
                    county = 0;
                    }
                   else if(iteration == 7){
                    countx = 6;
                    county = 3;
                    }
                   else if(iteration == 8){
                    countx = 6;
                    county = 6;
                    }
                  
                   
                  
         }    
            
        }    
        frame.add(Panel); //adding JPanel to Frame.
        
        /*Test Code
           */
          for (int i=0; i<9;i++){
                   
                for(int j =0; j<9;j++){
                    System.out.print(Game[i][j]);
                  }
                 System.out.println();
              }
       
    
  }
  public static void main(String[] args) {
        
        new SudokuGUI(); // calling construtctor
        
          }

}  
 
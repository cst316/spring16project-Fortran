/* Quy Ly
SER215
Due November 13, 2014
Assignment 8 Inheritance */

import java.io.*;

class Savings extends Account 
{
}

